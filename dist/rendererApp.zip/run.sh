java -Djava.library.path=`pwd`/lib/native/linux-amd64 -jar rendererApp.jar
